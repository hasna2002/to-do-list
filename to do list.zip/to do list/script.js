let timer;
let startTime;
let elapsedTime = 0;
let totalStudyTime = 0;
let isStudyActive = false;

function updateClock() {
    const now = new Date();
    const elapsed = now - startTime + elapsedTime;
    const seconds = Math.floor((elapsed / 1000) % 60);
    const minutes = Math.floor((elapsed / (1000 * 60)) % 60);
    const hours = Math.floor((elapsed / (1000 * 60 * 60)) % 24);

    document.getElementById('clock').innerText = `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
}

function pad(num) {
    return num < 10 ? '0' + num : num;
}

function startStudy() {
    if (!isStudyActive) {
        startTime = new Date();
        timer = setInterval(updateClock, 1000);
        isStudyActive = true;
    }
}

function startBreak() {
    if (isStudyActive) {
        clearInterval(timer);
        elapsedTime += new Date() - startTime;
        isStudyActive = false;
    }
}

function endSession() {
    if (isStudyActive) {
        clearInterval(timer);
        elapsedTime += new Date() - startTime;
        isStudyActive = false;
    }
    totalStudyTime += elapsedTime;
    updateTotalStudyTime();
    resetClock();
}

function resetClock() {
    elapsedTime = 0;
    document.getElementById('clock').innerText = '00:00:00';
}

function updateTotalStudyTime() {
    const seconds = Math.floor((totalStudyTime / 1000) % 60);
    const minutes = Math.floor((totalStudyTime / (1000 * 60)) % 60);
    const hours = Math.floor((totalStudyTime / (1000 * 60 * 60)) % 24);
    document.getElementById('total-study-time').innerText = `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
}